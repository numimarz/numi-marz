# Numi Marz

The official Numi Marz universe — music, modeling, stories, achievements, and lore.

## Season 1

The website is designed as a living archive. New levels can be unlocked as real achievements happen.

The current first version contains:
- Cinematic third-person introduction
- Season 1 framing
- Locked/unlocked level cards
- Achievement system placeholder
- Responsive design for phones and computers

The next build can add the exact visual details from the temporary site, real clickable level pages, achievement tracking, photos, music, video, and future chapters.
